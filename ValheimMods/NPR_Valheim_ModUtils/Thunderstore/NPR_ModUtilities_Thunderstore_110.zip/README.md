A lightweight collection of some mod helper tools including personal and Jotunn lib functionality.
Updated for Hildir compatability.